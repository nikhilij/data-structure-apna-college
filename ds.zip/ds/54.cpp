// maximum perfect numbers in length k
