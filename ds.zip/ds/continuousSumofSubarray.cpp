// subarray with given sum
// find a continuous subarray which adds to a given sum s

#include <bits/stdc++.h>
using namespace std;

int main()
{
    cout << "Enter how many elements:" << endl;

    int n;
    cin >> n;

    int a[n];
    cout << "Enter the elements: ";

    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }

    int sum;
    cout<<"Enter the target sum: ";
    cin>>sum;

    
}